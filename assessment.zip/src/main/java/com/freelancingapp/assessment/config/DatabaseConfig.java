package com.freelancingapp.assessment.config;

public class DatabaseConfig {
    
}
