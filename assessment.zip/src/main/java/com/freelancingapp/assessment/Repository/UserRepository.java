package com.freelancingapp.assessment.Repository;

public class UserRepository {
    
}
