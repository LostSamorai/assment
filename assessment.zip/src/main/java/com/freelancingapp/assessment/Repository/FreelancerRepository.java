package com.freelancingapp.assessment.Repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.freelancingapp.assessment.Model.Freelancer;

public interface FreelancerRepository extends JpaRepository<Freelancer, Long> {
}
