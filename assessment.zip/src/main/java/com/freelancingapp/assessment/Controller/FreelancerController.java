package com.freelancingapp.assessment.Controller;



import com.freelancingapp.assessment.Model.Freelancer;
import com.freelancingapp.assessment.Services.FreelancerService;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/freelancer")
public class FreelancerController {
    @Autowired
    private FreelancerService freelancerService;

    @PostMapping("/register")
    public Freelancer register(@RequestBody Freelancer freelancer) {
        return freelancerService.registerFreelancer(freelancer);
    }
}
