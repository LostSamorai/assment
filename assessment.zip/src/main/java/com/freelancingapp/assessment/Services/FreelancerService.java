package com.freelancingapp.assessment.Services;


import com.freelancingapp.assessment.Model.Freelancer;
import com.freelancingapp.assessment.Repository.FreelancerRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class FreelancerService {
    @Autowired
    private FreelancerRepository freelancerRepository;

    public Freelancer registerFreelancer(Freelancer freelancer) {
        return freelancerRepository.save(freelancer);
    }
}
