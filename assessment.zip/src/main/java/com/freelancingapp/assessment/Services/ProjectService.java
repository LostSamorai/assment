package com.freelancingapp.assessment.Services;

import com.freelancingapp.assessment.Model.Project;

import com.freelancingapp.assessment.Repository.ProjectRepository;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;




@Service
public class ProjectService {
    @Autowired
    private ProjectRepository projectRepository;

    public Project addProject(Project project) {
        return projectRepository.save(project);
    }

    public List<Project> searchProjects(String query) {
        return projectRepository.searchProjects(query);
    }
}
