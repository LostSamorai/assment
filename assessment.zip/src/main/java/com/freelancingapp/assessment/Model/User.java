
// import jakarta.persistence.Entity;
// import jakarta.persistence.Inheritance;
// import jakarta.persistence.Table;

// @Entity
// @Table(name = "users")
// @Inheritance(strategy = InheritanceType.JOINED)
// public class User extends BaseUser {
// }

package com.freelancingapp.assessment.Model;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@Entity
public class User extends BaseUser {
    // هنا ممكن تضيف أي خصائص إضافية للمستخدم
}
